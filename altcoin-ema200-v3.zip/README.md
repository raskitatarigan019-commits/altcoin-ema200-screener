# Altcoin EMA200 Screener V3

Single-page web app. Open `index.html` in a browser, or run `python3 -m http.server 8080` and visit http://localhost:8080.

- Screens 60 highest-24h-quote-volume OKX spot USDT pairs, not the full OKX universe.
- Downloads historical Daily candles using paginated OKX `/api/v5/market/history-candles` (up to 300 records); requires >=291 closed candles.
- Filters explicitly for OKX `confirm=1` and sorts chronologically.
- EMA values are seeded with the SMA of the first period. Confirmed breakout compares the last two closed candles with their corresponding EMA200 values.
- Volume 90D and 20D compare the signal candle to the *preceding* 90/20 closed candles.
- OBV trend, close position and relative volume are only technical proxies for accumulation, NOT wallet-level whale activity.
- Whale on-chain and fundamental metrics are not integrated and are explicitly marked unverified; never treat the proxy as verified whale accumulation.
- Score is a transparent heuristic, not a probability or forecast.
- Watchlist is stored in the browser's localStorage. No scheduled alerts, background monitoring, or GitHub/Vercel deployment.
- Browser access to OKX may fail because of regional access, CORS or rate limiting; a production version should use a backend proxy and cache.
